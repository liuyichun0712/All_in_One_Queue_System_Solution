// A simple demo of customer database
let customer = [
  {phone:'12345600', level:4}, // level 4 refers to Diamond
  {phone:'12345601', level:3}, // level 3 refers to Gold
  {phone:'12345602', level:2}, // level 2 refers to Silver
  {phone:'12345605', level:2},
  {phone:'12345606', level:2},
  {phone:'12345609', level:1}, // level 1 refers to Normal
  {phone:'12345610', level:1},
  {phone:'12345615', level:1},
  {phone:'12345618', level:1},
  {phone:'12345620', level:1},
  {phone:'22345600', level:4}, // level 4 refers to Diamond
  {phone:'22345601', level:3}, // level 3 refers to Gold
  {phone:'22345602', level:2}, // level 2 refers to Silver
  {phone:'22345605', level:2},
  {phone:'22345606', level:2},
  {phone:'22345609', level:1}, // level 1 refers to Normal
  {phone:'22345610', level:1},
  {phone:'22345615', level:1},
  {phone:'22345618', level:1},
  {phone:'22345620', level:1}
];

// All the global variables needed to be transferred between frontend and backend
/*
let bookingJ = [
  {phone:'12345610', num:'A001', slot_start:new Date(`2023-02-10 04:00:00`),slot_end:new Date(`2023-02-06 04:59:59`)},
  {phone:'12345600', num:'A002', slot_start:new Date(`2023-02-10 03:00:00`),slot_end:new Date(`2023-02-06 03:59:59`)},
  {phone:'12345605', num:'A003', slot_start:new Date(`2023-02-10 04:00:00`),slot_end:new Date(`2023-02-06 04:59:59`)},
  {phone:'12345609', num:'A004', slot_start:new Date(`2023-02-10 03:00:00`),slot_end:new Date(`2023-02-06 03:59:59`)}
]

let bookingO= [
  {phone:'12345610', num:'A001', slot_start:new Date(`2023-02-10 04:00:00`),slot_end:new Date(`2023-02-06 04:59:59`)},
  {phone:'12345600', num:'A002', slot_start:new Date(`2023-02-10 03:00:00`),slot_end:new Date(`2023-02-06 03:59:59`)},
  {phone:'12345605', num:'A003', slot_start:new Date(`2023-02-10 04:00:00`),slot_end:new Date(`2023-02-06 04:59:59`)},
  {phone:'12345609', num:'A004', slot_start:new Date(`2023-02-10 04:00:00`),slot_end:new Date(`2023-02-06 04:59:59`)}
]
*/
let bookingJ = [];
let bookingO = [];
let walkingJ = [];
let walkingO = [];
let waitingInfoJ = [];
let waitingInfoO = [];
let waitingListJ = [];
let waitingListO = [];
let missingListJ = [];
let missingListO = [];
let phone_number = '';
let client_number = '';
let client_number_email = '';
let slot_start = new Date();
let slot_end = new Date();
let arrive_time = new Date();
let level = 1;
let current_clientJ1 = '';
let current_clientJ2 = '';
let current_clientO1 = '';
let current_clientO2 = '';
let reschedule_number = '';
let d_length = 0;
let g_length = 0;
let s_length = 0;
let n_length = 0;
let d_stopJ = 0;
let g_stopJ = 0;
let s_stopJ = 0;
let n_stopJ = 0;
let d_stopO = 0;
let g_stopO = 0;
let s_stopO = 0;
let n_stopO = 0;
let category_to_show = '';
let show_list = [];
let queueCounter = 1;
let e_queueCounter = 1;
let branch = '';
let counter = '';


// Configuration
const express = require('express');
const app = express();
const port = 9000;
const path = require('path');

const cors = require('cors');
const nodemailer = require("nodemailer");
const bodyParser = require('body-parser');
app.set('view engine','ejs');

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static( __dirname )); //設置照片路徑
app.set('Jnum',0);
app.set('Onum',0);

app.listen(port, () => {
  console.log(`Example page listening on port ${port}`)
})

// API: online booking page
app.get('/onlineBooking', (req,res)=>{
  res.sendFile('homepage.html', {
    root: path.join(__dirname, './')
  })
})

// API: generate client number automatically
app.get("/newEntryWeb", (request, response) => {
  client_number = 'A' + (queueCounter++).toString().padStart(3, '0')
  response.send({client_number:client_number});
});

// API: send phone number to backend
app.post('/send-phonenumber', (request, response) => {
    phone_number = request.body.phone;
    console.log(`Received phone number: ${phone_number}`);
    response.send('Phone number received');
  });

// API: send other booking details to the backend
app.post("/send-slot-details", (request, response) => {
    const selectedSlot = request.body.slots;
    phone_number = request.body.phone;
    console.log(`Selected slot: ${selectedSlot}`);
    response.json({ slot_start: selectedSlot.split("-")[0], slot_end: selectedSlot.split("-")[1] });
    slot_start = selectedSlot.split("-")[0]
    slot_end = selectedSlot.split("-")[1]
    branch = request.body.branch;
    console.log(branch)
    const date = request.body.apptdate;
    console.log(date)
    slot_start = date + " " + slot_start + ":00"
    slot_end = date + " " + slot_end + ":00"
    console.log(slot_start)
    console.log(slot_end)
    if (branch == 'Jurong') {
      bookingJ.push({phone:phone_number, num:client_number, slot_start:new Date(slot_start), slot_end:new Date(slot_end)})
    }
    else if (branch == 'Orchard') {
      bookingO.push({phone:phone_number, num:client_number, slot_start:new Date(slot_start), slot_end:new Date(slot_end)})
    }
});

// API: to take a look at the list of online booking clients
app.get('/bookinglist/Jurong', (req,res) => {
  res.send(bookingJ)
})
app.get('/bookinglist/Orchard', (req,res) => {
  res.send(bookingO)
})

// send confirmation email to the client
app.post("/send-email", (request, response) => {
  const email = request.body.email;
  console.log(email)
  client_number_email = 'A' + (e_queueCounter++).toString().padStart(3, '0')
  const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      secure: false,
      auth: {
        user: 'pbxqueuesystem@gmail.com',
        pass: 'nntayqpzyxefnejh'
      }
    });
  
  const mailOptions = {
      from: 'pbxqueuesystem@gmail.com',
      to: email,
      subject: 'Registration successful at PBX Bank!',
      text: 'This is to confirm that you have successfully registered for an appointment at PBX Bank at the ' + branch + ' branch from ' + slot_start + ' to ' + slot_end + ' and your Appointment Queue number is: ' + client_number_email
    };
  
  transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.log(error);
        return response.status(500).json({ error: 'Email sending failed. Please try again.' });
      }
      console.log('Email sent: ' + info.response);
      response.json({ message: 'Email sent successfully!' });
    });
  response.json({ message: "Email sent successfully" });
});

// Walk-in page
app.get("/walk_in/Jurong",(req,res) => {
  branch = 'Jurong';
  res.render('walkin');
  app.get('/walk_in/branch', (req,res) => {
    res.send({b:branch});
  })
})

app.get("/walk_in/Orchard",(req,res) => {
  branch = 'Orchard';
  res.render('walkin');
  app.get('/walk_in/branch', (req,res) => {
    res.send({b:branch});
  })
})

// API: display the confirmation message to client and store the walk-in information into the backend database
app.use(bodyParser.urlencoded({ extended: false }));
app.get("/walk_in/submit",(req,res) => { 
  phone_number = req.query.phoneinput;
  [level, customer] = get_level(customer, phone_number);
  app.post('/walk_in/sendbranch', (req,res)=>{
    let { b } = req.body;
    branch = b;
  })
  if (branch == 'Jurong') {
    if ((level == 4 && d_stopJ == 1)|| (level == 3 && g_stopJ == 1)|| (level == 2 && s_stopJ == 1) ||(level == 1 && n_stopJ == 1)) {
      res.render('walkinsubmit',{status:"Sorry! The queue is closed.", num:""})
    } 
    else {
      arrive_time = new Date();
      slot_start = new Date('2023-01-01 23:59:59');
      slot_end = new Date('2023-01-01 23:00:00');
      app.settings.Jnum = app.settings.Jnum + 1;
      res.render('walkinsubmit',{status:'Success! Your booking has been made. Your number is: ' , num: 'B' + ("00" + app.settings.Jnum).slice(-3)})
      client_number = 'B' + ("00" + app.settings.Jnum).slice(-3);
      let dic = {num:client_number, phone:phone_number, arrive:arrive_time};
      walkingJ.push(dic);
      waitingInfoJ = arrival(waitingInfoJ, client_number, level, slot_start, slot_end, arrive_time);
      waitingInfoJ = update(waitingInfoJ);
      [waitingListJ, waitingInfoJ] = sort_clients(waitingInfoJ);
      console.log(waitingListJ);
    }
  }
  else if (branch == 'Orchard') {
    if ((level == 4 && d_stopO == 1)|| (level == 3 && g_stopO == 1)|| (level == 2 && s_stopO == 1) ||(level == 1 && n_stopO == 1)) {
      res.render('walkinsubmit',{status:"Sorry! The queue is closed.", num:""})
    }
    else {
      arrive_time = new Date();
      slot_start = new Date('2023-01-01 23:59:59');
      slot_end = new Date('2023-01-01 23:00:00');
      app.settings.Onum = app.settings.Onum + 1;
      res.render('walkinsubmit',{status:'Success! Your booking has been made. Your number is: ' , num: 'B' + ("00" + app.settings.Onum).slice(-3)})
      client_number = 'B' + ("00" + app.settings.Onum).slice(-3);
      let dic = {num:client_number, phone:phone_number, arrive:arrive_time};
      walkingO.push(dic);
      waitingInfoO = arrival(waitingInfoO, client_number, level, slot_start, slot_end, arrive_time);
      waitingInfoO = update(waitingInfoO);
      [waitingListO, waitingInfoO] = sort_clients(waitingInfoO);
      console.log(waitingListO);
    } 
  }
})

// API: to take a look at the list of walk-in clients
app.get('/walkinlist/Jurong', (req,res) => {
  res.send(walkingJ);
})
app.get('/walkinlist/Orchard', (req,res) => {
  res.send(walkingO);
})

// Display page
app.get('/display/Jurong',(req,res) => {
  branch = "Jurong";
  waitingInfoJ = update(waitingInfoJ);
  [waitingListJ, waitingInfoJ] = sort_clients(waitingInfoJ);
  res.render('display',{
    branch: branch,
    A1: current_clientJ1, 
    A2: current_clientJ2,
    Waiting: waitingListJ,
    Missing: missingListJ})
})

app.get('/display/Orchard',(req,res) => {
  branch = "Orchard";
  waitingInfoO = update(waitingInfoO);
  [waitingListO, waitingInfoO] = sort_clients(waitingInfoO);
  res.render('display',{
    branch: branch,
    A1: current_clientO1, 
    A2: current_clientO2, 
    Waiting: waitingListO,
    Missing: missingListO})
})

// Sign-in page
app.get("/sign_in/Jurong",(req,res)=>{
  branch = 'Jurong';
  app.get('/sign_in/branch', (req,res) => {
    res.send({b:branch})
  })
  res.render('signin');
})

app.get("/sign_in/Orchard",(req,res)=>{
  branch = 'Orchard';
  app.get('/sign_in/branch', (req,res) => {
    res.send({b:branch})
  })
  res.render('signin')
})

// API: sign in
app.get("/get-number",(req,res)=>{
  client_number = req.query.queueNumber;
  app.post('/sign_in/sendbranch', (req,res)=>{
    let { b } = req.body;
    branch = b;
  })
  arrive_time = new Date();
  if (branch == 'Jurong') {
    [phone_number, slot_start, slot_end] = sign_in(bookingJ, client_number);
    if (phone_number == -1) {
      var answer = "You didn't make a reservation."
      res.render('get-number',{answer:answer})
    }
    else {
      [level, customer] = get_level(customer, phone_number);
      waitingInfoJ = arrival(waitingInfoJ, client_number, level, slot_start, slot_end, arrive_time);
      waitingInfoJ = update(waitingInfoJ);
      [waitingListJ, waitingInfoJ] = sort_clients(waitingInfoJ);
      console.log(waitingListJ);
      if (slot_start<=arrive_time && slot_end>=arrive_time) {//arrive on time
        var answer = `You are successfully check in!\n
        Your slot is at ${slot_start} to ${slot_end}`
        res.render('get-number',{answer:answer})
      }
      else if (slot_start>arrive_time) {//arrive early
        var answer = `You are successfully check in but arrive early.\n
        Your slot is at ${slot_start} to ${slot_end}.\n
        We will let you get the service as soon as possible.`
        res.render('get-number',{answer:answer})
      }
      else {//arrive late
        var answer =`Sorry, you are late.\n
        Your slot is at ${slot_start} to ${slot_end}.\n
        Since your slot time is over, your priority will be the same as walk-in.`
        res.render('get-number',{answer:answer})
      } 
    }
  }
  else if (branch == 'Orchard') {
    [phone_number, slot_start, slot_end] = sign_in(bookingO, client_number);
    if (phone_number == -1) {
      var answer = "You didn't make a reservation."
      res.render('get-number',{answer:answer})
    }
    else {
      [level, customer] = get_level(customer, phone_number);
      waitingInfoO = arrival(waitingInfoO, client_number, level, slot_start, slot_end, arrive_time);
      waitingInfoO = update(waitingInfoO);
      [waitingListO, waitingInfoO] = sort_clients(waitingInfoO);
      console.log(waitingListO);
      if (slot_start<=arrive_time && slot_end>=arrive_time) {//arrive on time
        var answer = `You are successfully check in!\n
        Your slot is at ${slot_start} to ${slot_end}`
        res.render('get-number',{answer:answer})
      }
      else if (slot_start>arrive_time) {//arrive early
        var answer = `You are successfully check in but arrive early.\n
        Your slot is at ${slot_start} to ${slot_end}.\n
        We will let you get the service as soon as possible.`
        res.render('get-number',{answer:answer})
      }
      else {//arrive late
        var answer =`Sorry, you are late.\n
        Your slot is at ${slot_start} to ${slot_end}.\n
        Since your slot time is over, your priority will be the same as walk-in.`
        res.render('get-number',{answer:answer})
      } 
    }
  }
})

// Counter selection page
app.get('/selectcounter', (req,res)=>{
  res.render('selectCounter',{
      root: path.join(__dirname,"./")
  });
});

// go to the Counter function page
app.get('/counter', (req, res) => {
  branch = req.query.branch;
  counter = req.query.counter;
  res.sendFile('counter_function.html', {
    root: path.join(__dirname, './')
  })
  app.get('/counter/getbranch_counter', (req, res) => { // API: get branch and display it on the page
    res.send({b:branch, c:counter});
  });
}); 

// API: call next client
app.get('/counter/nextClient', (req,res)=>{
  app.post('/counter/sendbranch_counter', (req,res)=>{
    let { b } = req.body;
    branch = b;
    let { c } = req.body;
    counter = c;
  })
  if (branch == 'Jurong' && counter == '1') {
    [current_clientJ1, waitingListJ, waitingInfoJ] = call_client(waitingInfoJ);
    if (current_clientJ1 == undefined) {
      res.send({newQ_no: "No New Client"});
    }
    else {
      res.send({newQ_no: current_clientJ1})
    }
    console.log(waitingListJ);
  }
  else if (branch == 'Jurong' && counter == '2') {
    [current_clientJ2, waitingListJ, waitingInfoJ] = call_client(waitingInfoJ);
    if (current_clientJ2 == undefined) {
      res.send({newQ_no: "No New Client"});
    }
    else {
      res.send({newQ_no: current_clientJ2})
    }
    console.log(waitingListJ);
  }
  else if (branch == 'Orchard' && counter == '1') {
    [current_clientO1, waitingListO, waitingInfoO] = call_client(waitingInfoO);
    if (current_clientO1 == undefined) {
      res.send({newQ_no: "No New Client"});
    }
    else {
      res.send({newQ_no: current_clientO1})
    }
    console.log(waitingListO);
  }
  else if (branch == 'Orchard' && counter == '2') {
    [current_clientO2, waitingListO, waitingInfoO] = call_client(waitingInfoO);
    if (current_clientO2 == undefined) {
      res.send({newQ_no: "No New Client"});
    }
    else {
      res.send({newQ_no: current_clientO2})
    }
    console.log(waitingListO);
  }
})

// API: clear current client
app.post('/counter/clearingNumber', (req, res) => {
  let { b } = req.body;
  branch = b;
  let { c } = req.body;
  counter = c;
  if (branch == 'Jurong' && counter == '1') {
    let { cur } = req.body;
    current_clientJ1 = cur;
  }
  else if (branch == 'Jurong' && counter == '2') {
    let { cur } = req.body;
    current_clientJ2 = cur;
  }
  else if (branch == 'Orchard' && counter == '1') {
    let { cur } = req.body;
    current_clientO1 = cur;
  }
  else if (branch == 'Orchard' && counter == '2') {
    let { cur } = req.body;
    current_clientO2 = cur;
  }
})

// API: hold current client
app.post('/counter/holdingNumber', (req, res) => {
  let { b } = req.body;
  branch = b;
  let { c } = req.body;
  counter = c;
  if (branch == 'Jurong' && counter == '1') {
    let { cur } = req.body;
    current_clientJ1 = cur;
    let {missing} = req.body;
    missingListJ.push(missing);
  }
  else if (branch == 'Jurong' && counter == '2') {
    let { cur } = req.body;
    current_clientJ2 = cur;
    let {missing} = req.body;
    missingListJ.push(missing);
  }
  else if (branch == 'Orchard' && counter == '1') {
    let { cur } = req.body;
    current_clientO1 = cur;
    let {missing} = req.body;
    missingListO.push(missing);
  }
  else if (branch == 'Orchard' && counter == '2') {
    let { cur } = req.body;
    current_clientO2 = cur;
    let {missing} = req.body;
    missingListO.push(missing);
  }
}); 

// CRO selection page
app.get('/selectcro', (req,res)=>{
  res.render('cro_select',{
      root: path.join(__dirname,"./")
  });
});

// go to the CRO function page
app.get('/cro', (req, res) => {
  branch = req.query.branch
  res.render('cro_function');
  // API: get branch and display it on the page
  app.get('/cro/getbranch', (req, res) => { 
    res.send({b:branch});
  });
}); 

// API: to get the number of waiting clients of each category
app.get('/cro/getInfo', (req,res)=>{
  app.post('/cro/sendbranch', (req,res)=>{
    let { b } = req.body;
    branch = b;
  })
  if (branch == 'Jurong'){
    [d_length, g_length, s_length, n_length] = count_client(waitingInfoJ);
  }
  else if (branch == 'Orchard') {
    [d_length, g_length, s_length, n_length] = count_client(waitingInfoO);
  }
  res.send({
    d_count: d_length,
    g_count: g_length,
    s_count: s_length,
    n_count: n_length,
  });
});

// API: to refresh the CRO page
app.get('/cro/refresh', (req,res)=>{
  app.post('/cro/sendbranch', (req,res)=>{
    let { b } = req.body;
    branch = b;
  })
  if (branch == 'Jurong') {
    [d_length, g_length, s_length, n_length] = count_client(waitingInfoJ);
  }
  else if (branch == 'Orchard') {
    [d_length, g_length, s_length, n_length] = count_client(waitingInfoO);
  }
  res.send({
    d_count: d_length,
    g_count: g_length,
    s_count: s_length,
    n_count: n_length
  })
});

/* API: the missing client show up at the branch and get rescheduled
app.get('/cro/reque',(req,res)=>{
  app.post('/cro/requenumber', (req,res)=>{
    let { b } = req.body;
    branch = b;
    let { reque } = req.body;
    reschedule_number = reque;
  })
  if (branch == 'Jurong') {
    let index = missingListJ.indexOf(reschedule_number);
    if (index > -1) {
      missingListJ.splice(index, 1);
      [phone_number, slot_start, slot_end] = sign_in(bookingJ, reschedule_number); // to check if he made a reservation before
      if (phone_number == -1) { // didn't make a reservation before
        phone_number = getPhoneFromWalking(walkingJ, reschedule_number);
      }
      arrive_time = new Date();
      [level, customer] = get_level(customer, phone_number);
      waitingInfoJ = arrival(waitingInfoJ, reschedule_number, level, slot_start, slot_end, arrive_time);
      waitingInfoJ = update(waitingInfoJ);
      [waitingListJ, waitingInfoJ] = sort_clients(waitingInfoJ);
      res.send({msg:`${reschedule_number} is already re-queued!`})
    }
    else {
      res.send({msg:`${reschedule_number} does not exist!`})
    }
  }
  else if (branch == 'Orchard') {
    let index = missingListO.indexOf(reschedule_number);
    if (index > -1) {
      missingListO.splice(index, 1);
      [phone_number, slot_start, slot_end] = sign_in(bookingO, reschedule_number); // to check if he made a reservation before
      if (phone_number == -1) { // didn't make a reservation before
        phone_number = getPhoneFromWalking(walkingO, reschedule_number);
      }
      arrive_time = new Date();
      [level, customer] = get_level(customer, phone_number);
      waitingInfoO = arrival(waitingInfoO, reschedule_number, level, slot_start, slot_end, arrive_time);
      waitingInfoO = update(waitingInfoO);
      [waitingListO, waitingInfoO] = sort_clients(waitingInfoO);
      res.send({msg:`${reschedule_number} is already re-queued!`})
    }
    else {
      res.send({msg:`${reschedule_number} does not exist!`})
    }
  }
})*/

// API: the missing client show up at the branch and get rescheduled
app.post('/cro/requenumber', (req,res)=>{
  let { b } = req.body;
  branch = b;
  let { reque } = req.body;
  reschedule_number = reque;
  if (branch == 'Jurong') {
    let index = missingListJ.indexOf(reschedule_number);
    if (index > -1) {
      missingListJ.splice(index, 1);
      [phone_number, slot_start, slot_end] = sign_in(bookingJ, reschedule_number); // to check if he made a reservation before
      if (phone_number == -1) { // didn't make a reservation before
        phone_number = getPhoneFromWalking(walkingJ, reschedule_number);
      }
      arrive_time = new Date();
      [level, customer] = get_level(customer, phone_number);
      waitingInfoJ = arrival(waitingInfoJ, reschedule_number, level, slot_start, slot_end, arrive_time);
      waitingInfoJ = update(waitingInfoJ);
      [waitingListJ, waitingInfoJ] = sort_clients(waitingInfoJ);
    }
  }
  else if (branch == 'Orchard') {
    let index = missingListO.indexOf(reschedule_number);
    if (index > -1) {
      missingListO.splice(index, 1);
      [phone_number, slot_start, slot_end] = sign_in(bookingO, reschedule_number); // to check if he made a reservation before
      if (phone_number == -1) { // didn't make a reservation before
        phone_number = getPhoneFromWalking(walkingO, reschedule_number);
      }
      arrive_time = new Date();
      [level, customer] = get_level(customer, phone_number);
      waitingInfoO = arrival(waitingInfoO, reschedule_number, level, slot_start, slot_end, arrive_time);
      waitingInfoO = update(waitingInfoO);
      [waitingListO, waitingInfoO] = sort_clients(waitingInfoO);
    }
  }
})



// API: to change the service state of diamond category
app.post('/cro/d_stop', (req, res) => {
  let { status } = req.body;
  var d_status = status ;
  let { b } = req.body;
  branch = b;
  if (branch == 'Jurong') {
    if (d_status == "On-going") {
      d_stopJ = 1;
    }
    else {
      d_stopJ = 0;
    }
  }
  else if (branch == 'Orchard') {
    if (d_status == "On-going") {
      d_stopO = 1;
    }
    else {
      d_stopO = 0;
    }
  }
}); 

// API: to change the service state of gold category
app.post('/cro/g_stop', (req, res) => {
  let { status } = req.body;
  var g_status = status ;
  let { b } = req.body;
  branch = b;
  if (branch == 'Jurong') {
    if (g_status == "On-going") {
      g_stopJ = 1;
    }
    else {
      g_stopJ = 0;
    }
  }
  else if (branch == 'Orchard') {
    if (g_status == "On-going") {
      g_stopO = 1;
    }
    else {
      g_stopO = 0;
    }
  }
}); 

// API: to change the service state of silver category
app.post('/cro/s_stop', (req, res) => {
  let { status } = req.body;
  var s_status = status ;
  let { b } = req.body;
  branch = b;
  if (branch == 'Jurong') {
    if (s_status == "On-going") {
      s_stopJ = 1;
    }
    else {
      s_stopJ = 0;
    }
  }
  else if (branch == 'Orchard') {
    if (s_status == "On-going") {
      s_stopO = 1;
    }
    else {
      s_stopO = 0;
    }
  }
}); 

// API: to change the service state of normal category
app.post('/cro/n_stop', (req, res) => {
  let { status } = req.body;
  var n_status = status ;
  let { b } = req.body;
  branch = b;
  if (branch == 'Jurong') {
    if (n_status == "On-going") {
      n_stopJ = 1;
    }
    else {
      n_stopJ = 0;
    }
  }
  else if (branch == 'Orchard') {
    if (n_status == "On-going") {
      n_stopO = 1;
    }
    else {
      n_stopO = 0;
    }
  }
}); 


// to show the specific category
app.get('/cro/queueDetail', (req,res)=>{
  category_to_show = req.query.member_category;
  app.post('/cro/sendbranch', (req,res)=>{
    let { b } = req.body;
    branch = b;
  })
  if (branch == 'Jurong') {
    show_list = show_category(waitingInfoJ, category_to_show);
  }
  else if (branch == 'Orchard') {
    show_list = show_category(waitingInfoO, category_to_show);
  }
  res.render('cro_display', {
    selectedCat: category_to_show,
    queue: show_list
  })
})


// Functions used in the backend
function sign_in(bookingList, client_no) {
  // the bookingList is sorted by client number, use binary search
  let low = 0;
  let high = bookingList.length - 1;
  while (low <= high) {
    let mid = Math.floor((low + high) / 2);
    if (bookingList[mid].num == client_no) {
      return [bookingList[mid].phone, bookingList[mid].slot_start, bookingList[mid].slot_end];
    }
    else if (bookingList[mid].num < client_no) {
      low = mid + 1;
    }
    else {
      high = mid - 1;
    }
  }
  return [-1, new Date('2023-01-01 23:59:59'), new Date('2023-01-01 23:00:00')];
}

function get_level(customerList, phoneNo) {
  // the customerList is sorted by phone number, use binary search
  let low = 0;
  let high = customerList.length - 1;
  while(low <= high) {
    let mid = Math.floor((low + high) / 2);
    if (customerList[mid].phone == phoneNo) {
      return [customerList[mid].level, customerList];
    }
    else if (customerList[mid].phone < phoneNo) {
      low = mid + 1;
    }
    else {
      high = mid - 1;
    }
  }
  idx = Math.max(low, high);
  // insert new client into the customer database according to the searching index
  customerList.splice(idx, 0, {phone:phoneNo, level:1});
  return [1, customerList];
}

function arrival(infoList, client_no, client_level, slot_start, slot_end, arrive_time) {
  let in_slot = 0;
  let max_time = 30*60*1000;
  if (arrive_time >= slot_start && arrive_time <= slot_end) {
    in_slot = 1;
  }
  if (client_level > 2) {
    max_time = 15*60*1000;
  }
  let temp = [client_no, client_level, slot_start, arrive_time, in_slot, max_time, 0];
  infoList.push(temp);
  return infoList;
}

function update(info) {
  let current = new Date();
  for (let i=0; i<info.length; i++) {
    let each = info[i];
    // update waiting time state
    let waiting_time = current - each[3];
    if (waiting_time > each[5]) {
      each[6] = 1;
    }
    // for early arrival, check whether it comes to his slot time
    if (each[4] == 0) {
      if(each[3] < each[2] && current >= each[2]) {
        each[4] = 1;
      } 
    }
  }
  return info;
}

function sort_clients(info) {
  let p1 = []; // priority 1: book in advance, arrive on time and already wait for a long time
  let p2 = []; // priority 2: book in advance, arrive on time
  let p3 = []; // priority 3: walk in and already wait for a long time
  let p4 = []; // priority 4: walk in wait for a short time
  for (let i=0; i<info.length; i++) {
    let each = info[i];
    if (each[4] * each[6] == 1) {
      p1.push(each);      
    }
    else if (each[4] == 1) {
      p2.push(each);
    }
    else if (each[6] == 1) {
      p3.push(each);
    }
    else {
      p4.push(each);
    }
  }
  // for each group, sort by client level
  p1.sort(function(x,y){
    return y[1] - x[1];
  })
  p2.sort(function(x,y){
    return y[1] - x[1];
  })
  p3.sort(function(x,y){
    return y[1] - x[1];
  })
  p4.sort(function(x,y){
    return y[1] - x[1];
  })
  let sorted_info = [...p1, ...p2, ...p3, ...p4]; // merge the 4 groups together
  let waiting = [];
  for (let i=0; i<sorted_info.length; i++) {
    waiting.push(sorted_info[i][0]);
  }
  return [waiting, sorted_info];
}

function call_client(info) {
  let info1 = update(info);
  let [waiting, info2] = sort_clients(info1);
  let next_client = waiting.shift();
  info2.shift();
  return [next_client, waiting, info2];
}

function count_client(info) {
  let d = 0;
  let g = 0;
  let s = 0;
  let n = 0;
  for (let i=0; i<info.length; i++) {
    let each = info[i];
    if (each[1] == 4) {
      d = d + 1;
    }
    else if (each[1] == 3) {
      g = g + 1;
    }
    else if (each[1] == 2) {
      s = s + 1;
    }
    else {
      n = n + 1;
    }
  }
  return [d, g, s, n];
}

function show_category(info, cat) {
  let show_list = [];
  let level = 1;
  if (cat == "Diamond") {
    level = 4;
  }
  else if (cat == "Gold") {
    level = 3;
  }
  else if (cat == "Silver") {
    level = 2;
  }
  else {
    level = 1;
  }
  for (let i=0; i<info.length; i++) {
    let each = info[i];
    if (each[1] == level) {
      show_list.push(each[0]);
    }
  }
  return show_list;
}

function getPhoneFromWalking(wlist, num) {
  // the walking list is sorted by client number, use binary search
  let low = 0;
  let high = wlist.length - 1;
  while(low <= high) {
    let mid = Math.floor((low + high) / 2);
    if (wlist[mid].num == num) {
      return wlist[mid].phone;
    }
    else if (wlist[mid].num < num) {
      low = mid + 1;
    }
    else {
      high = mid - 1;
    }
  }
}